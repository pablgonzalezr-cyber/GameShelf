-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 18-05-2026 a las 05:37:15
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_videojuego`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `videojuegos`
--

CREATE TABLE `videojuegos` (
  `id` bigint(20) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `precio` double NOT NULL,
  `categoria_id` bigint(20) NOT NULL,
  `nombre_categoria` varchar(80) NOT NULL,
  `plataforma` varchar(40) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `videojuegos`
--

INSERT INTO `videojuegos` (`id`, `titulo`, `descripcion`, `precio`, `categoria_id`, `nombre_categoria`, `plataforma`, `estado`) VALUES
(1, 'Minecraft', 'Juego sandbox de construccion y aventura', 15000, 1, 'AVENTURA', 'PC', 'DISPONIBLE'),
(2, 'The Legend of Zelda Breath of the Wild', 'Juego de aventura y exploracion en mundo abierto', 25000, 1, 'AVENTURA', 'NINTENDO SWITCH', 'DISPONIBLE'),
(3, 'FIFA 24', 'Videojuego deportivo de futbol', 18000, 2, 'DEPORTES', 'PLAYSTATION 5', 'DISPONIBLE'),
(4, 'Resident Evil 4 Remake', 'Juego de accion y terror de supervivencia', 22000, 3, 'TERROR', 'PC', 'DISPONIBLE'),
(5, 'Elden Ring', 'Juego RPG de accion en mundo abierto', 28000, 4, 'RPG', 'PLAYSTATION 5', 'DISPONIBLE'),
(6, 'Mario Kart 8 Deluxe', 'Juego de carreras arcade multijugador', 20000, 5, 'CARRERAS', 'NINTENDO SWITCH', 'DISPONIBLE'),
(7, 'God of War Ragnarok', 'Juego de accion y aventura basado en mitologia nordica', 26000, 1, 'AVENTURA', 'PLAYSTATION 5', 'DISPONIBLE'),
(8, 'Hollow Knight', 'Juego metroidvania de accion y exploracion', 12000, 1, 'AVENTURA', 'PC', 'DISPONIBLE'),
(9, 'Stardew Valley Expanded', 'Juego de simulacion, granja, aventura y exploracion', 13000, 1, 'Aventura', 'PC', 'INACTIVO'),
(10, 'The forest', 'Juego de supervivencia y exploracion', 16000, 3, 'Supervivencia', 'PC', 'DISPONIBLE'),
(11, 'Dark Forest Trial', 'Videojuego de accion ambientado en un bosque oscuro', 18990, 11, 'SOULSLIKE', 'PC', 'DISPONIBLE');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `videojuegos`
--
ALTER TABLE `videojuegos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `videojuegos`
--
ALTER TABLE `videojuegos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
