-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 18-05-2026 a las 05:36:26
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_categoria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `nombre` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `descripcion`, `estado`, `nombre`) VALUES
(1, 'Videojuegos centrados en exploración, historia y progresión narrativa', 'INACTIVO', 'Aventura'),
(2, 'Videojuegos relacionados con fútbol, básquetbol, carreras deportivas y competencias', 'ACTIVO', 'Deportes'),
(3, 'Videojuegos donde el jugador debe recolectar recursos y sobrevivir', 'ACTIVO', 'Supervivencia'),
(4, 'Videojuegos enfocados en suspenso, miedo y supervivencia', 'ACTIVO', 'Terror'),
(5, 'Videojuegos de conducción, velocidad y competencias con vehículos', 'ACTIVO', 'Carreras'),
(6, 'Videojuegos de rol con progresión de personaje, misiones y mundo abierto', 'ACTIVO', 'RPG'),
(7, 'Videojuegos centrados en combate, reflejos y enfrentamientos directos', 'ACTIVO', 'Acción'),
(8, 'Videojuegos donde se requiere planificación, gestión de recursos y toma de decisiones', 'ACTIVO', 'Estrategia'),
(9, 'Videojuegos donde el jugador supera niveles con saltos, obstáculos y enemigos', 'ACTIVO', 'Plataformas 2D'),
(10, 'subgénero de los videojuegos de rol que se caracterizan generalmente por la exploración de mazorras con niveles generados de forma procedimental', 'ACTIVO', 'ROGUELIKE'),
(11, 'Categoria para juegos dificiles de accion y exploracion', 'ACTIVO', 'SOULSLIKE');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKqcog8b7hps1hioi9onqwjdt6y` (`nombre`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
