-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-05-2026 a las 05:01:06
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_usuario`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `rol` varchar(30) NOT NULL,
  `usuario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `contrasena`, `correo`, `rol`, `usuario`) VALUES
(1, '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin@gameshelf.cl', 'ADMIN', 'admin'),
(2, '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'cliente1@gameshelf.cl', 'CLIENTE', 'cliente1'),
(3, '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'cliente2@gameshelf.cl', 'CLIENTE', 'cliente2'),
(4, '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'empleado1@gameshelf.cl', 'EMPLEADO', 'empleado1'),
(6, '$2a$10$IxwqX7t31LCu8Kx4II4jg.SWdkvX6gdww.vNfz06eEMy2UGq2Dep2', 'prueba.final@gameshelf.cl', 'CLIENTE', 'usuario_prueba_final'),
(7, '$2a$10$614wMMjGH7E/jUxpWr9z9.T0VooSTntuokcdZDI.MzI5JoxNQKGRS', 'david@duoc.cl', 'TESTER', 'david_06'),
(8, '$2a$10$bSjRpj49zrtW1UWx6jyp7OJfIexzd76CE441QVM6q2n7kS/YUCHL6', 'robert123@gameshelf.cl', 'CLIENTE', 'roberto'),
(9, '$2a$10$Tk1oFFTZCOWQGrgqdT68Xeg3oc.sAVkQ5CheoqtPdSCBj2y/3tr76', 'gabi938@gmail.duoc', 'CLIENTE', 'gabriel'),
(10, '$2a$10$8bfwfhC4LQJjLTRZkMaZhucTErdcssRbpHfuMfU3rEugz.mGWY9KW', 'diana123@gmail.duoc', 'CLIENTE', 'diana'),
(11, '$2a$10$XrPaMpusQIH9HoG.w7XdEu3y/BsWhGJTmRU1qKh4xKHPoO3OrgzIK', 'robert9843@gmail.duoc', 'CLIENTE', 'robert'),
(12, '$2a$10$AzZdo08qk8jU89EN9HI1nen.R/ef3xo3gb13dGBoPVjOevm9SRx.2', 'juanito123@gmail.duoc', 'CLIENTE', 'juansd');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKcdmw5hxlfj78uf4997i3qyyw5` (`correo`),
  ADD UNIQUE KEY `UK3m5n1w5trapxlbo2s42ugwdmd` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
