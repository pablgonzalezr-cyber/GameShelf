-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-05-2026 a las 05:00:19
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_autorizacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autorizaciones`
--

CREATE TABLE `autorizaciones` (
  `id` bigint(20) NOT NULL,
  `usuario_id` bigint(20) NOT NULL,
  `rol` varchar(255) DEFAULT NULL,
  `modulo` varchar(255) DEFAULT NULL,
  `permiso` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `autorizaciones`
--

INSERT INTO `autorizaciones` (`id`, `usuario_id`, `rol`, `modulo`, `permiso`, `estado`) VALUES
(1, 1, 'ADMIN', 'SISTEMA', 'TOTAL', 'ACTIVO'),
(2, 1, 'ADMIN', 'RESERVAS', 'TOTAL', 'ACTIVO'),
(3, 1, 'ADMIN', 'PRESTAMOS', 'TOTAL', 'ACTIVO'),
(4, 1, 'ADMIN', 'MULTAS', 'TOTAL', 'ACTIVO'),
(5, 2, 'CLIENTE', 'CATALOGO', 'VER_CATALOGO', 'ACTIVO'),
(6, 2, 'CLIENTE', 'RESERVAS', 'CREAR_RESERVA', 'ACTIVO'),
(7, 3, 'EMPLEADO', 'CATALOGO', 'VER_CATALOGO', 'ACTIVO'),
(8, 3, 'EMPLEADO', 'PRESTAMOS', 'GESTIONAR_PRESTAMOS', 'ACTIVO'),
(9, 3, 'EMPLEADO', 'MULTAS', 'GESTIONAR_MULTAS', 'ACTIVO'),
(10, 4, 'TESTER', 'SISTEMA', 'TESTEADOR', 'ACTIVO');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autorizaciones`
--
ALTER TABLE `autorizaciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autorizaciones`
--
ALTER TABLE `autorizaciones`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
