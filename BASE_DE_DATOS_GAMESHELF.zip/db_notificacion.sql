-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-05-2026 a las 05:00:35
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_notificacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` bigint(20) NOT NULL,
  `usuario_id` bigint(20) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `mensaje` varchar(500) NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `fecha_lectura` datetime DEFAULT NULL,
  `referencia_id` bigint(20) DEFAULT NULL,
  `referencia_tipo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `usuario_id`, `titulo`, `mensaje`, `tipo`, `estado`, `fecha_creacion`, `fecha_lectura`, `referencia_id`, `referencia_tipo`) VALUES
(1, 1, 'Reserva actualizada', 'Tu reserva fue actualizada correctamente', 'RESERVA', 'ELIMINADA', '2026-05-16 02:41:56', '2026-05-17 14:48:23', 1, 'RESERVA'),
(2, 1, 'Prestamo creado', 'Tu prestamo fue registrado correctamente', 'PRESTAMO', 'LEIDA', '2026-05-17 14:14:42', '2026-05-17 14:44:19', NULL, NULL),
(3, 1, 'Reserva creada', 'Tu reserva fue registrada correctamente', 'RESERVA', 'PENDIENTE', '2026-05-17 14:47:47', NULL, 1, 'RESERVA'),
(4, 6, 'Reserva creada', 'Tu reserva fue registrada correctamente', 'RESERVA', 'LEIDA', '2026-05-17 15:02:45', '2026-05-17 15:08:12', 3, 'RESERVA'),
(5, 6, 'Préstamo creado', 'Tu préstamo fue registrado correctamente', 'PRESTAMO', 'PENDIENTE', '2026-05-17 15:04:29', NULL, 5, 'PRESTAMO'),
(6, 6, 'Préstamo devuelto', 'Tu préstamo fue devuelto correctamente', 'PRESTAMO', 'PENDIENTE', '2026-05-17 15:05:36', NULL, 5, 'PRESTAMO'),
(7, 6, 'Multa generada', 'Se generó una multa por atraso en la devolución', 'MULTA', 'PENDIENTE', '2026-05-17 15:07:05', NULL, 4, 'MULTA'),
(8, 7, 'Reserva registrada', 'Tu reserva de Dark Forest Trial fue creada correctamente', 'RESERVA', 'LEIDA', '2026-05-17 19:32:14', '2026-05-17 19:40:34', 4, 'RESERVA'),
(9, 7, 'Préstamo creado', 'Tu préstamo de Dark Forest Trial fue registrado correctamente', 'PRESTAMO', 'PENDIENTE', '2026-05-17 19:35:18', NULL, 5, 'PRESTAMO'),
(10, 7, 'Multa generada', 'Se ha generado una multa de prueba asociada a tu préstamo', 'MULTA', 'LEIDA', '2026-05-17 19:38:33', '2026-05-17 19:40:22', 5, 'MULTA');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
